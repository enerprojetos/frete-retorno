import { View, Text } from 'react-native'
export default function ShipperHome() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Área da Empresa</Text>
    </View>
  )
}
