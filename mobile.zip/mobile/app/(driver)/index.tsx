import { View, Text } from 'react-native'
export default function DriverHome() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Área do Motorista</Text>
    </View>
  )
}
