// importe polyfills/side-effects aqui no futuro, antes do entry
import 'expo-router/entry'
